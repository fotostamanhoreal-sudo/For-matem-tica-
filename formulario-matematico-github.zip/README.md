# 📐 Formulário Matemático

Fórmulas, constantes e figuras matemáticas por área de uso, com calculadora, download em CSV/XLSX/PDF e 10 idiomas (pt, en, zh, hi, es, fr, ar, bn, ru, ur).

Criado por **Guilherme Morais Nascimento** — guilhermenascimento867@gmail.com

## Publicar no GitHub Pages
1. Crie um repositório público (ex.: `formulario-matematico`) e envie todos os arquivos desta pasta.
2. Em **Settings → Pages**, escolha *Deploy from a branch*, branch `main`, pasta `/ (root)`.
3. Substitua os marcadores abaixo (no Linux/macOS/Git Bash):

```bash
sed -i 's#https://SEU-USUARIO.github.io/formulario-matematico/#https://SEUUSER.github.io/SEUREPO/#g; s#G-XXXXXXXXXX#G-SEUID#g; s#SEU_CODIGO_DO_SEARCH_CONSOLE#SEUCODIGO#g' index.html sitemap.xml robots.txt
```

- `G-XXXXXXXXXX`: ID de medição do Google Analytics 4.
- `SEU_CODIGO_DO_SEARCH_CONSOLE`: código de verificação do Google Search Console (ou remova a meta tag).
4. No Search Console, adicione a propriedade e envie `sitemap.xml`.

Arquivos: `index.html` (site), `robots.txt`, `sitemap.xml`, `.nojekyll`.
